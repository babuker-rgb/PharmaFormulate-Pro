import { GoogleGenAI, Type } from "@google/genai";

export interface Ingredient {
  id: string;
  name: string;
  type: 'API' | 'Binder' | 'Filler' | 'Disintegrant' | 'Lubricant' | 'Glidant' | 'Other';
  amount: number; // in mg or %
  unit: 'mg' | '%';
}

export interface OptimizationTarget {
  property: string;
  goal: 'minimize' | 'maximize' | 'target';
  value?: number;
  weight: number; // 1-10
}

export interface Formulation {
  id: string;
  name: string;
  ingredients: Ingredient[];
  predictedProperties: Record<string, number>;
  timestamp: number;
  notes?: string;
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const optimizeFormulation = async (
  currentIngredients: Ingredient[],
  targets: OptimizationTarget[],
  constraints: string
): Promise<{
  suggestedIngredients: Ingredient[];
  predictedProperties: Record<string, number>;
  rationale: string;
}> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `
      You are an expert pharmaceutical formulation scientist. 
      Optimize the following tablet formulation based on the provided targets and constraints.
      
      Current Ingredients:
      ${JSON.stringify(currentIngredients, null, 2)}
      
      Optimization Targets:
      ${JSON.stringify(targets, null, 2)}
      
      Additional Constraints:
      ${constraints}
      
      Provide a new optimized formulation and predict the resulting properties.
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          suggestedIngredients: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                type: { type: Type.STRING },
                amount: { type: Type.NUMBER },
                unit: { type: Type.STRING }
              },
              required: ["name", "type", "amount", "unit"]
            }
          },
          predictedProperties: {
            type: Type.OBJECT,
            description: "Predicted values for properties like Hardness (N), Friability (%), Disintegration Time (min), etc.",
            properties: {
              hardness: { type: Type.NUMBER },
              friability: { type: Type.NUMBER },
              disintegrationTime: { type: Type.NUMBER },
              dissolutionRate: { type: Type.NUMBER }
            }
          },
          rationale: {
            type: Type.STRING,
            description: "Scientific explanation for the suggested changes."
          }
        },
        required: ["suggestedIngredients", "predictedProperties", "rationale"]
      }
    }
  });

  return JSON.parse(response.text);
};
