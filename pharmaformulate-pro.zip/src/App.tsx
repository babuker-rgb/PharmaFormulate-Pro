/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Trash2, 
  Beaker, 
  Target, 
  Zap, 
  History, 
  ChevronRight, 
  Info,
  Save,
  RefreshCw,
  BarChart3,
  Settings2
} from 'lucide-react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { 
  Ingredient, 
  OptimizationTarget, 
  Formulation, 
  optimizeFormulation 
} from './services/geminiService';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const INGREDIENT_TYPES = ['API', 'Binder', 'Filler', 'Disintegrant', 'Lubricant', 'Glidant', 'Other'] as const;

export default function App() {
  const [ingredients, setIngredients] = useState<Ingredient[]>([
    { id: '1', name: 'Paracetamol', type: 'API', amount: 500, unit: 'mg' },
    { id: '2', name: 'Microcrystalline Cellulose', type: 'Binder', amount: 150, unit: 'mg' },
    { id: '3', name: 'Starch', type: 'Disintegrant', amount: 50, unit: 'mg' },
    { id: '4', name: 'Magnesium Stearate', type: 'Lubricant', amount: 5, unit: 'mg' },
  ]);

  const [targets, setTargets] = useState<OptimizationTarget[]>([
    { property: 'Hardness', goal: 'target', value: 100, weight: 8 },
    { property: 'Friability', goal: 'minimize', weight: 10 },
    { property: 'Disintegration Time', goal: 'minimize', weight: 7 },
    { property: 'Dissolution Rate', goal: 'maximize', weight: 9 },
  ]);

  const [constraints, setConstraints] = useState('Maintain total tablet weight below 750mg. Ensure API concentration is exactly 500mg.');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [result, setResult] = useState<{
    suggestedIngredients: Ingredient[];
    predictedProperties: Record<string, number>;
    rationale: string;
  } | null>(null);

  const [history, setHistory] = useState<Formulation[]>([]);

  const addIngredient = () => {
    const newIngredient: Ingredient = {
      id: Math.random().toString(36).substr(2, 9),
      name: '',
      type: 'Filler',
      amount: 0,
      unit: 'mg'
    };
    setIngredients([...ingredients, newIngredient]);
  };

  const updateIngredient = (id: string, updates: Partial<Ingredient>) => {
    setIngredients(ingredients.map(ing => ing.id === id ? { ...ing, ...updates } : ing));
  };

  const removeIngredient = (id: string) => {
    setIngredients(ingredients.filter(ing => ing.id !== id));
  };

  const handleOptimize = async () => {
    setIsOptimizing(true);
    try {
      const optimizationResult = await optimizeFormulation(ingredients, targets, constraints);
      setResult(optimizationResult);
      
      // Add to history
      const newFormulation: Formulation = {
        id: Math.random().toString(36).substr(2, 9),
        name: `Optimization ${history.length + 1}`,
        ingredients: optimizationResult.suggestedIngredients,
        predictedProperties: optimizationResult.predictedProperties,
        timestamp: Date.now(),
        notes: optimizationResult.rationale
      };
      setHistory([newFormulation, ...history]);
    } catch (error) {
      console.error("Optimization failed", error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const radarData = useMemo(() => {
    if (!result) return [];
    return Object.entries(result.predictedProperties).map(([key, value]) => ({
      subject: key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1'),
      A: value,
      fullMark: 100,
    }));
  }, [result]);

  const compositionData = useMemo(() => {
    const ings = result ? result.suggestedIngredients : ingredients;
    return ings.map(ing => ({
      name: ing.name || 'Unnamed',
      value: ing.amount,
      type: ing.type
    }));
  }, [ingredients, result]);

  return (
    <div className="min-h-screen flex flex-col technical-grid">
      {/* Header */}
      <header className="h-16 border-b border-slate-200 bg-white/80 backdrop-blur-md flex items-center px-8 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-sky-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-sky-200">
            <Beaker size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">PharmaFormulate <span className="text-sky-600">Pro</span></h1>
            <p className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold">Tablet Optimization Engine v2.4</p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <button className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 rounded-lg transition-colors">
            <History size={18} />
            History
          </button>
          <button 
            onClick={handleOptimize}
            disabled={isOptimizing}
            className="flex items-center gap-2 px-6 py-2 bg-slate-900 text-white rounded-lg text-sm font-semibold hover:bg-slate-800 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isOptimizing ? <RefreshCw className="animate-spin" size={18} /> : <Zap size={18} />}
            {isOptimizing ? 'Optimizing...' : 'Run Optimization'}
          </button>
        </div>
      </header>

      <main className="flex-1 p-8 grid grid-cols-12 gap-8 max-w-[1600px] mx-auto w-full">
        {/* Left Column: Inputs */}
        <div className="col-span-12 lg:col-span-4 space-y-8">
          {/* Ingredients Section */}
          <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center gap-2">
                <Settings2 size={18} className="text-sky-600" />
                <h2 className="font-bold text-slate-800">Current Formulation</h2>
              </div>
              <button 
                onClick={addIngredient}
                className="p-1.5 hover:bg-white rounded-md border border-transparent hover:border-slate-200 transition-all text-sky-600"
              >
                <Plus size={20} />
              </button>
            </div>
            <div className="p-5 space-y-4">
              {ingredients.map((ing) => (
                <div key={ing.id} className="flex gap-3 items-start group">
                  <div className="flex-1 space-y-2">
                    <input 
                      type="text" 
                      placeholder="Ingredient Name"
                      value={ing.name}
                      onChange={(e) => updateIngredient(ing.id, { name: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all"
                    />
                    <div className="flex gap-2">
                      <select 
                        value={ing.type}
                        onChange={(e) => updateIngredient(ing.id, { type: e.target.value as any })}
                        className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-600 focus:outline-none"
                      >
                        {INGREDIENT_TYPES.map(type => (
                          <option key={type} value={type}>{type}</option>
                        ))}
                      </select>
                      <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-lg px-2">
                        <input 
                          type="number" 
                          value={ing.amount}
                          onChange={(e) => updateIngredient(ing.id, { amount: Number(e.target.value) })}
                          className="w-16 bg-transparent text-sm font-mono focus:outline-none text-right"
                        />
                        <span className="text-[10px] font-bold text-slate-400 uppercase">{ing.unit}</span>
                      </div>
                    </div>
                  </div>
                  <button 
                    onClick={() => removeIngredient(ing.id)}
                    className="mt-2 p-1.5 text-slate-300 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              ))}
            </div>
          </section>

          {/* Targets Section */}
          <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center gap-2">
                <Target size={18} className="text-sky-600" />
                <h2 className="font-bold text-slate-800">Optimization Targets</h2>
              </div>
            </div>
            <div className="p-5 space-y-4">
              {targets.map((target, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-slate-700">{target.property}</span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Weight: {target.weight}</span>
                  </div>
                  <div className="flex gap-2">
                    <select 
                      value={target.goal}
                      onChange={(e) => {
                        const newTargets = [...targets];
                        newTargets[idx].goal = e.target.value as any;
                        setTargets(newTargets);
                      }}
                      className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-600 focus:outline-none"
                    >
                      <option value="minimize">Minimize</option>
                      <option value="maximize">Maximize</option>
                      <option value="target">Target Value</option>
                    </select>
                    {target.goal === 'target' && (
                      <input 
                        type="number"
                        value={target.value}
                        onChange={(e) => {
                          const newTargets = [...targets];
                          newTargets[idx].value = Number(e.target.value);
                          setTargets(newTargets);
                        }}
                        className="w-20 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-sm font-mono focus:outline-none"
                      />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Constraints */}
          <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex items-center gap-2">
              <Info size={18} className="text-sky-600" />
              <h2 className="font-bold text-slate-800">Constraints & Notes</h2>
            </div>
            <div className="p-5">
              <textarea 
                value={constraints}
                onChange={(e) => setConstraints(e.target.value)}
                placeholder="Enter regulatory or manufacturing constraints..."
                className="w-full h-32 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 transition-all resize-none"
              />
            </div>
          </section>
        </div>

        {/* Right Column: Results & Visualization */}
        <div className="col-span-12 lg:col-span-8 space-y-8">
          <AnimatePresence mode="wait">
            {!result ? (
              <motion.div 
                key="empty"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="h-full flex flex-col items-center justify-center text-center p-12 bg-white/50 rounded-3xl border-2 border-dashed border-slate-200"
              >
                <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 mb-6">
                  <BarChart3 size={40} />
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-2">Ready for Optimization</h3>
                <p className="text-slate-500 max-w-md">
                  Configure your ingredients and targets, then click "Run Optimization" to generate AI-powered formulation suggestions.
                </p>
              </motion.div>
            ) : (
              <motion.div 
                key="results"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-8"
              >
                {/* Top Stats/Charts Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Radar Chart: Predicted Performance */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6">Predicted Performance Profile</h3>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                          <PolarGrid stroke="#e2e8f0" />
                          <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }} />
                          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                          <Radar
                            name="Optimized"
                            dataKey="A"
                            stroke="#0ea5e9"
                            fill="#0ea5e9"
                            fillOpacity={0.3}
                          />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Bar Chart: Composition */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-6">Optimized Composition (mg)</h3>
                    <div className="h-[300px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={compositionData} layout="vertical">
                          <XAxis type="number" hide />
                          <YAxis 
                            dataKey="name" 
                            type="category" 
                            width={100} 
                            tick={{ fontSize: 10, fill: '#64748b' }} 
                          />
                          <Tooltip 
                            cursor={{ fill: 'transparent' }}
                            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                          />
                          <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                            {compositionData.map((entry, index) => (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={entry.type === 'API' ? '#0ea5e9' : '#94a3b8'} 
                              />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Suggested Formulation Table */}
                <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="font-bold text-slate-800">Optimized Formulation Recipe</h3>
                    <button className="flex items-center gap-2 px-4 py-1.5 bg-sky-50 text-sky-700 rounded-full text-xs font-bold hover:bg-sky-100 transition-colors">
                      <Save size={14} />
                      Save as Preset
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50/50">
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Ingredient</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Function</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Amount</th>
                          <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Change</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {result.suggestedIngredients.map((ing, idx) => {
                          const original = ingredients.find(i => i.name === ing.name);
                          const diff = original ? ing.amount - original.amount : ing.amount;
                          return (
                            <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                              <td className="px-6 py-4">
                                <span className="text-sm font-semibold text-slate-700">{ing.name}</span>
                              </td>
                              <td className="px-6 py-4">
                                <span className="px-2 py-1 bg-slate-100 text-slate-500 rounded text-[10px] font-bold uppercase">{ing.type}</span>
                              </td>
                              <td className="px-6 py-4 text-right">
                                <span className="text-sm font-mono font-medium text-slate-900">{ing.amount} {ing.unit}</span>
                              </td>
                              <td className="px-6 py-4 text-right">
                                <span className={cn(
                                  "text-[10px] font-bold px-2 py-0.5 rounded-full",
                                  diff > 0 ? "bg-emerald-50 text-emerald-600" : diff < 0 ? "bg-rose-50 text-rose-600" : "bg-slate-50 text-slate-400"
                                )}>
                                  {diff > 0 ? '+' : ''}{diff === 0 ? 'No change' : `${diff} ${ing.unit}`}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Rationale / AI Insights */}
                <div className="bg-slate-900 rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-8 opacity-10">
                    <Beaker size={120} />
                  </div>
                  <div className="relative z-10">
                    <div className="flex items-center gap-2 mb-6">
                      <div className="w-8 h-8 bg-sky-500 rounded-lg flex items-center justify-center">
                        <Zap size={18} />
                      </div>
                      <h3 className="font-bold text-lg">Optimization Rationale</h3>
                    </div>
                    <div className="prose prose-invert prose-sm max-w-none text-slate-300 leading-relaxed">
                      <Markdown>{result.rationale}</Markdown>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Footer / Status Bar */}
      <footer className="h-10 border-t border-slate-200 bg-white flex items-center px-8 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            System Ready
          </div>
          <div className="flex items-center gap-2">
            <ChevronRight size={12} />
            Model: Gemini 3 Flash
          </div>
          <div className="flex items-center gap-2">
            <ChevronRight size={12} />
            Session ID: {Math.random().toString(36).substr(2, 6).toUpperCase()}
          </div>
        </div>
        <div className="ml-auto">
          © 2026 PharmaFormulate Pro • Confidential
        </div>
      </footer>
    </div>
  );
}
